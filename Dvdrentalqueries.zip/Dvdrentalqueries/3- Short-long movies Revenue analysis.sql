SELECT 
    f.film_id,
    f.title,
    f.length,
    CASE 
        WHEN f.length < 90 THEN 'Short (<90 mins)'
        WHEN f.length > 150 THEN 'Long (>150 mins)'
        ELSE 'Normal'
    END AS film_type,
    SUM(p.amount) AS total_revenue,
    COUNT(r.rental_id) AS rentals_count
FROM film f
JOIN inventory i ON f.film_id = i.film_id
JOIN rental r ON i.inventory_id = r.inventory_id
JOIN payment p ON r.rental_id = p.rental_id
WHERE f.length < 90 OR f.length > 150
GROUP BY f.film_id, f.title, f.length
ORDER BY total_revenue DESC
LIMIT 10;
