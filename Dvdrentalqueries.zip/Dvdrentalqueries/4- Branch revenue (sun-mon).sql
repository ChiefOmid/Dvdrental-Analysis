SELECT 
    s.store_id,
    TO_CHAR(r.rental_date, 'Day') AS day_of_week,
    SUM(p.amount) AS total_revenue
FROM store s
JOIN inventory i ON s.store_id = i.store_id
JOIN rental r ON i.inventory_id = r.inventory_id
JOIN payment p ON r.rental_id = p.rental_id
WHERE EXTRACT(ISODOW FROM r.rental_date) IN (6, 7)  
GROUP BY s.store_id, TO_CHAR(r.rental_date, 'Day')
ORDER BY total_revenue DESC;
