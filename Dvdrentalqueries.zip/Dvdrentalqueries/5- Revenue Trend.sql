WITH seasonal_revenue AS (
    SELECT 
        DATE_PART('year', p.payment_date) AS year,
        CASE 
            WHEN DATE_PART('month', p.payment_date) IN (12, 1, 2) THEN 'Winter'
            WHEN DATE_PART('month', p.payment_date) IN (3, 4, 5) THEN 'Spring'
            WHEN DATE_PART('month', p.payment_date) IN (6, 7, 8) THEN 'Summer'
            WHEN DATE_PART('month', p.payment_date) IN (9, 10, 11) THEN 'Autumn'
        END AS season,
        SUM(p.amount) AS total_revenue
    FROM payment p
    GROUP BY year, season
)
SELECT 
    year,
    season,
    total_revenue,
    ROUND(
        (total_revenue - LAG(total_revenue) OVER (ORDER BY year, season)) 
        / NULLIF(LAG(total_revenue) OVER (ORDER BY year, season), 0) * 100, 
        2
    ) AS growth_percentage
FROM seasonal_revenue
ORDER BY year, 
    CASE season 
        WHEN 'Winter' THEN 1
        WHEN 'Spring' THEN 2
        WHEN 'Summer' THEN 3
        WHEN 'Autumn' THEN 4
    END;
