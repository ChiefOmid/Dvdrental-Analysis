WITH film_genres AS (
    SELECT 
        f.film_id,
        STRING_AGG(c.name, ', ' ORDER BY c.name) AS genre_combo
    FROM film f
    JOIN film_category fc ON f.film_id = fc.film_id
    JOIN category c ON fc.category_id = c.category_id
    GROUP BY f.film_id
),
film_revenue AS (
    SELECT 
        f.film_id,
        SUM(p.amount) AS total_revenue
    FROM film f
    JOIN inventory i ON f.film_id = i.film_id
    JOIN rental r ON i.inventory_id = r.inventory_id
    JOIN payment p ON r.rental_id = p.rental_id
    GROUP BY f.film_id
)
SELECT 
    fg.genre_combo,
    COUNT(fg.film_id) AS film_count,
    SUM(fr.total_revenue) AS total_revenue,
    ROUND(SUM(fr.total_revenue) / COUNT(fg.film_id), 2) AS avg_revenue_per_film
FROM film_genres fg
JOIN film_revenue fr ON fg.film_id = fr.film_id
GROUP BY fg.genre_combo
ORDER BY total_revenue DESC
LIMIT 10;
